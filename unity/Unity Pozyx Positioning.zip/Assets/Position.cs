﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Text;
using UnityOSC;
using System.IO.Ports;
using System.IO;

public class Position : MonoBehaviour
{
    [Tooltip("Uncheck to use OSC, check to use serial.")]
    public bool useSerial = true;

    [Tooltip("Whether to automatically select the device's serial port.")]
    public bool automaticSerialPortSelect = true;

    [Tooltip("Serial port to use. Will only be used if automatic port select is unchecked.")]
    public string serialPort = "COM1";

    [Tooltip("Port number for OSC communication.")]
    public int OSCPort = 8888;

    public GameObject player;

    public List<string> IDs = new List<string>();
    private List<GameObject> players = new List<GameObject>();

    private const int baudRate = 115200;
    private SerialPort serial;

    private Dictionary<string, ServerLog> servers;

    // Use this for initialization
    void Start()
    {
        if (useSerial)
        {
            if (automaticSerialPortSelect)
            {
                string[] ports = SerialPort.GetPortNames();
                string correctPortName = getCorrectCOMPortPath(ports[0]);
                serial = new SerialPort(correctPortName, baudRate);
            }
            else
            {
                serial = new SerialPort(serialPort, baudRate);
            }

            serial.Open();
            serial.ReadTimeout = 10;
        }
        else
        {
            OSCHandler.Instance.Init();
            servers = new Dictionary<string, ServerLog>();
        }
    }

    string getCorrectCOMPortPath(string COMPortPath)
    {
        int COMPortIndex = Int32.Parse(COMPortPath.Split('M')[1]);
        if (COMPortIndex > 9)
        {
            return "\\\\.\\" + COMPortPath;
        }
        else
        {
            return COMPortPath;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (useSerial)
        {
            try
            {
                string readLine = serial.ReadLine();
                Debug.Log(readLine);
                string[] pos = readLine.Split(',');
                if (pos[0].Equals("POS"))
                {
                    string ID = pos[1];
                    int x = Int32.Parse(pos[2]);
                    int y = Int32.Parse(pos[3]);
                    int z = Int32.Parse(pos[4]);
                    AddPosition(ID, x, y, z);
                }
            }
            catch (System.Exception)
            {
            }
        }
        else
        {
            if (OSCHandler.NewPackets.Count > 0)
            {
                Debug.Log(OSCHandler.NewPackets.Count);
                foreach (OSCPacket packet in OSCHandler.NewPackets)
                {
                    if (packet.Address.Equals("/position"))
                    {
                        string ID = (string)packet.Data[0];
                        int x = (int)packet.Data[1];
                        int y = (int)packet.Data[2];
                        int z = (int)packet.Data[3];
                        AddPosition(ID, x, y, z);
                    }
                }
                OSCHandler.NewPackets.Clear();
            }
        }
    }

    void AddPosition(string ID, int x, int y, int z)
    {
        for (int i = 0; i < IDs.Count; i++)
        {
            if (IDs[i].Equals(ID))
            {
                players[i].transform.position = new Vector3(x / 1000.0f,
                                                            y / 1000.0f,
                                                            z / 1000.0f);
                return;
            }
        }
        Debug.Log("Adding new object!");
        // not in current ID list
        IDs.Add(ID);
        GameObject new_player = GameObject.Instantiate<GameObject>(player);
        new_player.transform.position = new Vector3(x / 1000.0f,
                                                    y / 1000.0f,
                                                    z / 1000.0f);
        new_player.name = String.Format("Player {0}", IDs.Count);
        players.Add(new_player);
    }
}
